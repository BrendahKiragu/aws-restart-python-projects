import re
 
def clean(data: str) -> str:
    # Remove 'ORIGIN', '//' and whitespace
    cleaned_data = re.sub(r'ORIGIN|\d+|//|\s+', '', data)
    # Confirm it has 110 characters
    print("Length of sequence:", len(cleaned_data))
    print("Here is your cleaned sequence:", cleaned_data)
    return cleaned_data
 
# Input sequence
data = """ORIGIN       
        1 malwmrllpl lallalwgpd paaafvnqhl cgshlvealy lvcgergffy tpktrreaed
       61 lqvgqvelgg gpgagslqpl alegslqkrg iveqcctsic slyqlenycn
//"""
cleaned_sequence = clean(data)

# Extract different segments
first_24_amino_acids = cleaned_sequence[:24]  # Amino acids 1-24
amino_25_to_54 = cleaned_sequence[24:54]      # Amino acids 25-54
amino_55_to_89 = cleaned_sequence[54:89]      # Amino acids 55-89
amino_90_to_110 = cleaned_sequence[89:110]    # Amino acids 90-110

# Save to lsinsulin-seq-clean.txt (first 24 amino acids)
with open("lsinsulin-seq-clean.txt", "w") as file:
    file.write(first_24_amino_acids)
print("lsinsulin-seq-clean.txt written successfully. Length:", len(first_24_amino_acids))

# Save to binsulin-seq-clean.txt (amino acids 25–54, 30 characters)
with open("binsulin-seq-clean.txt", "w") as file:
    file.write(amino_25_to_54)
print("binsulin-seq-clean.txt written successfully. Length:", len(amino_25_to_54))

# Save to cinsulin-seq-clean.txt (amino acids 55–89, 35 characters)
with open("cinsulin-seq-clean.txt", "w") as file:
    file.write(amino_55_to_89)
print("cinsulin-seq-clean.txt written successfully. Length:", len(amino_55_to_89))

# Save to ainsulin-seq-clean.txt (amino acids 90–110, 21 characters)
with open("ainsulin-seq-clean.txt", "w") as file:
    file.write(amino_90_to_110)
print("ainsulin-seq-clean.txt written successfully. Length:", len(amino_90_to_110))
