print("Python has three numeric types: int, float, and complex")
myValue = 1
print(myValue)
print(type(myValue))

print(str(myValue) + " is the data type of " + str(type(myValue)))
miValue = 3.14
print(miValue)
print(type(miValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myComplex = 6j
print(myComplex)
print(type(myComplex))
print(str(myComplex) + " is of the data type " + str(type(myComplex)))

myBool = True
print(myBool)
print(type(myBool))
print(str(myBool) + " is of the data type " + str(type(myBool)))

myBool = False
print(myBool)
print(type(myBool))
print(str(myBool) + " is of the data type " + str(type(myBool)))