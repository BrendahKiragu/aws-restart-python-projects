print("Hello, Future cloud Pythoner")
name = input("Enter Your name: ")
print(f'Welcome, {name}')